import './style.css'

export default function FaleConosco(){
    function handleSubmit(event){
        event.preventDefalut()
        alert("Mensagem enviada com sucesso.")
    }

    return(
        <section className='contato'>
            <h1>Fale conosco</h1>
            <p>Tire as dúvidas e peça um orçamento sem compromisso</p>

            <form className='form' onSubmit={handleSubmit}>
                <div>
                    <label className='campo'>
                        <span>Nome</span>
                        <input type="text" required placeholder='Seu nome' />
                    </label>

                     <label className='campo'>
                        <span>E-mail</span>
                        <input type="text" required placeholder='Seu e-mail' />
                    </label>

                     <label className='campo'>
                        <span>Telefone</span>
                        <input type="text" required placeholder='(00) 99999-9999'/>
                    </label>
                </div>

                    <label className='campo'>
                        <span>Assunto</span>
                        <input type="text" required placeholder='Abertura de empresa'/>
                    </label>

                     <label className='campo'>
                        <span>Mensagem</span>
                        <textarea rows="6" required placeholder='Conte-nos um pouco de seu caso...'/>
                    </label>

                    <button type='submit'>Enviar</button>
            </form>

        </section>
    )

}
