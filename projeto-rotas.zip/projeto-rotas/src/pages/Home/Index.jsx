import { Link } from 'react-router-dom'
import logo from '../../assets/logo.png'
import equipe from '../../assets/equipe.png'
import './style.css'

export default function Home(){
    <div className='home'>
        <section className='logo'>
                <div>
                    <h1>Contabilidade descomplicada para o seu negócio</h1>  
                    <p>Economize tempo e foque no que importa.
                    Cuidamos de folha de pagamento, imposto  e obrigações com tecnologia
                    e atendimento humano</p>

                    <div>
                        <Link to="/fale-conosco">fale com conosco</Link>
                    </div>

                </div>
               
               <div>
                <img src={logo} alt="Logo da empresa"/>
               </div>
        </section>
            
        <section>
            
            <h2>Por que nos escolher ?</h2>
            
            <div>
                <div className='card'>
                    <h3>Atendimento próximo</h3>
                    <p>Suporte rápido por whatsApp, e-mail e reuniões online sempre que precisa.</p>
                </div>
                
                <div className='card'>
                    <h3>Tecnologia</h3>
                    <p>Interações com bancos e plataforma para automatizar lançamento e reduzir erros.</p>
                </div>
                
                <div className='card'>
                    <h3>Planejamento tributarios</h3>
                    <p>Escolha o redime ideal e estratégias legais para pagar menos imposto</p>
                </div>

            </div>
        </section>    

        <section>
            
            <div>
                <div>
                    <img src={equipe} alt="Equipe de contabilidade" />
                </div>
            </div>
            
            <div>
                <h2>Mais 200 empresas atendidas</h2>  
                <p>De MEIs a pequenas e médias empresas em todo o Brasil.
                    Cases em comércio, servidor e tecnologia.</p>
             </div>       
        </section>   

    </div>
}