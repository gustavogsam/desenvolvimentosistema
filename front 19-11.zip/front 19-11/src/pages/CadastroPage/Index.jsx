import './style.css';
import * as yup from 'yup';
import {useForm} from 'react-hook-form';
import {yupResolver} from '@hookform/resolvers/yup';
import {toast} from 'react-toastify';
import api from '../../service/api';

const esquemaDeCadastro = yup.object({
    nome: yup
    .string()
    .required('O nome é obrigatório')
    .min(3,'o nome deve ter pelo menos 3 caracteres'),
    email: yup
    .email('Email inválido')
    .required('O e-mail é obrigatório'),
    senha: yup
    .string()
    .min(6, 'a senha deve ter pelo menos 6 caracterisca')
    .required('A senha é obrigatória')

})

export default function CadastroPage(){
    const {
        register: registrarCampo,
        handleSubmit:lidarComNovoFormalario,
        formState:{erros:errosDoFormulario, isSubmitting:estaEnviando},
        SetErro:definirErroNoCampo,
        reset:limpaCampoDosFormulario
    } = useForm({
        resolver: esquemaDeCadastro,
        defaultValues:{
            nome:'',
            email:'',
            senha:'',
        },

    });

    async function enviarDados(dadosDoFormulario){
        const dadosParaEnvio ={
            name: dadosDoFormulario.nome,
            email: dadosDoFormulario.email,
            senha:dadosDoFormulario.senha,
        };

    }try{
        const resposta = await.api.post('/users',dadosParaEnvio);
        toast.success('Funcionario Cadastro com sucesso!');
        limpaCampoDosFormulario();
    } catch(error){
        const codigoStatus = error.response?.status;
        const mensagemDoServidor = error.response?.data?.mensagem ||
        'Erro ao cadastrar funcionario. Tente novamente mais tarde.';

        if(codigoStatus === 400){
            definirErroNoCampo('email',{
                type: 'server',
                message: mensagemDoServidor
            });
        }else{
            toast.error(mensagemDoServidor);
            console.error('Erro ao cadastrar funcionário:',error);
        }
    }
    
    return(
        <>
        <div className='cadastro-container'>
            <h1>Cadastro de Funcionário</h1>
            <form noValidate onSubmit={lidarComEnviaDoFormulario(enviarDados)}>
            {/*Nome*/}
            <div className='form-group'>
                <label htmlFor='campo-nome'>Nome:</label>
                <input type='text'
                id = 'campo-nome'
                placeholder='Ex.: João Silva' 
                {...registrarCampo('nome')}
                />

            </div>
            {errosDoFormulario.nome &&(
                <span className='erro-massage'>{errosDoFormulario.nome.message}</span>)}
            {/*email*/}
            <div className='form-group'>
                <label htmlFor='campo-email'>Email</label>
                <input 
                type= 'email'
                id= 'compo-email'
                placeholder='Ex.: lucas@asdas.com:'
                {...registrarCampo('email')}
                />
                </div>
                 {errosDoFormulario.email &&(
                <span className='erro-massage'>{errosDoFormulario.email.message}</span>)}
            {/*senha*/}
            <div className='form-group'>
                <label htmlFor='campo-email'>Senha</label>
                <input 
                type= 'password'
                id= 'compo-senha'
                placeholder='Digite uma senha segura'
                {...registrarCampo('senha')}
             />
             </div>
                 {errosDoFormulario.senha &&(
                <span className='erro-massage'>{errosDoFormulario.senha.message}</span>)}
                {/*Botão de Envio*/}
                <div className='form-group'>
                <button type='submit' disabled={estaEnviando}>
                {estaEnviando?'Cadastrando..' : 'Casdastrar'}
                </button>
                </div>
           </form>
        </div>
            
    </>
    );
}
