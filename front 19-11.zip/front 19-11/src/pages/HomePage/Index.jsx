import './style.css'

export default function HomePage(){
    return(
        <>
        <div className="home-container">
        <h1>Bem-Vindo ao Sistema de Cadastro de Funcionario</h1>
        <p>Use a navegação acima para cadastrar ou listar os funcionarios</p>
        </div>
        </>
    );
}