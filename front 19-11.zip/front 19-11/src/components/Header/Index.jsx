import {Link} from 'react-router-dom'
import './style.css'

export default function Header(){
    return(
        <>
        <header className='header'>
            <Link to="/">SENAI</Link>
            <nav>
                <Link to ="/cadastro">Cadastar Funcionario</Link>
                <Link to ="/funcionarios">Listar Funcionarios</Link>
            </nav>
        </header>
        </>
    );
}