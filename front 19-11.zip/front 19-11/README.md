# Instalação:

Progrmas para instalar neste projeto.

```
npm i axios yup react-router-dom react-toastify react-hook-form @hookform/resolvers
```