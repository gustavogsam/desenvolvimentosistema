import './style.css'

export default function Header(){
    return(
        <header className='header'>
            <div>Sistema Escolar </div>
        </header>

    )

}