import { useState } from 'react'
import './style.css'

export default function AdicionarAluno(){

    const[nome, SetNome] = useState('')
    const[email,SetEmail] = useState('')

const [listaAluno, SetlistaAluno] = useState([])

const addAluno = (event) => {
    event.preventDefault()
    if(nome && email){
        SetlistaAluno([...listaAluno,{nome,email}])
        SetNome('')
        SetEmail('')
    }
}

return(

    <><h2>Adicionar Aluno</h2><form onSubmit={addAluno}>

        <input
            type='text'
            placeholder='Nome'
            value={nome}
            onChange={(e) => SetNome(e.target.value)} />


        <input
            type="email"
            placeholder='E-mail'
            value={email}
            onChange={(e) => SetEmail(e.target.value)} />

        <button type='submit'>Adicionar</button>

    </form><hr /><h3>Matriculados</h3><ol>
            {listaAluno.map((aluno, index) => (
                <li key={index}>
                    {aluno.nome} - {aluno.email}

                </li>

            ))}
        </ol></>


)

}
