import './style.css'

export default function(){
    return(
        <footer className='footer' >
        <p>&copy;{new Date().getFullYear()} - Todos os direitos reservados
        <br/>Caos
        </p>
        </footer>
    )

}

