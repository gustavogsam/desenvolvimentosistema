import './App.css'
import Footer from './components/Footer'
import Header from './components/Header'
import AdicionarAluno from './components/AdicionarAluno'

function App() {
  
  return (
    <>
      <Header/>
      <h1>CAOS</h1>
      <AdicionarAluno></AdicionarAluno>
      
      <Footer/>  
    </>
  )
}

export default App
