import { useState } from 'react'
import './style.css'

export default function InfoCurso(){
    
    const [Nome,setNome] = useState('Desenvolvimento de Sistemas')
    
    return(
       <div className='infocurso'>
        <h2>Dados do curso</h2>
        <p><strong>Nome: </strong> Desenvolvimento de Sistema</p>
        <p><strong>Carga Horaria </strong> 158 horas</p>
        <p><strong>Local: </strong> Senai</p>
               </div>
    )
}