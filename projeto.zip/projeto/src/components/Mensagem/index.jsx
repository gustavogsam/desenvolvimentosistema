import './style.css'

export default function Mensagem(){
    return(
        <div className = 'mensagem'>
            <h1>Bem-vindo ao projeto</h1>
            <p>Este é um componente simples</p>
        </div>
    )
}