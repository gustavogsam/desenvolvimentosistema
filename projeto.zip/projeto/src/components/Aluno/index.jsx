import './style.css'

export default function Aluno(){
    return(
        <div className = 'aluno'>
            <h1>Nome:Gustavo</h1>
            <p>gg@email.com</p>
            <p>000.000.00.00</p>
        </div>
    )
}