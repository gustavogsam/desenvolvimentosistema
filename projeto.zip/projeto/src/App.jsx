import './App.css'
import Mensagem from './components/Mensagem'

function App() {
  

  return (
    <>
      <h1>Senai</h1>
      <Mensagem></Mensagem>
      <InfoCurso></InfoCurso>
      <Aluno></Aluno>

    </>
  )
}

export default App

// criar um componentes para aluno
//nome
//email
//CPF
