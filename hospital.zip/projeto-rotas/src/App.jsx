
import './App.css'


import Home from './pages/Home'
import SobreNos from './pages/SobreNos'
import FaleConosco from './pages/FaleConosco'
import Header from './components/Header'
import Footer from './components/Footer'
import Especialidade from './pages/Especialidade'

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
 

  return (
    <>
    <div className='App'>
      <Header/>
      <main>
        <Routes>
            <Route path='/home' element={<Home />} />
            <Route path='/sobre-nos' element={<SobreNos />} />
            <Route path='/fale-conosco' element={<FaleConosco />} />
            <Route path='/especialidade' element={<Especialidade/>} />
            
        </Routes>

      </main>
      <Footer />
    </div>
    </>
  )
}

export default App
