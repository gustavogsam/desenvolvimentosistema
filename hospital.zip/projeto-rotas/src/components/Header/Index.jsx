import './style.css'
import logo from '../../assets/logo.png'
import { NavLink,Link } from 'react-router-dom'

export default function Header() {
    return(
         <header className='header'>
             <Link to="/">
                <img src={logo} alt="Logo da hospital" />
                 <h1>Hospital São Miguel</h1>
            </Link>

            <nav className='nav'>
                <NavLink to="/home"> Home | </NavLink>
                <NavLink to="/sobre-nos"> Sobre nós | </NavLink>
                <NavLink to="/fale-conosco"> Fale conosco | </NavLink>
                <NavLink to="/especialidade"> Especilidade  </NavLink>
            </nav>
        </header>
    )

}