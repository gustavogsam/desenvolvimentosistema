import './style.css'

export default function Footer() {
    return(
    <footer className='footer'>
        
        <div>
            <strong> Avenida Saúde, N: 7 - Ribeira - Salvador/Ba</strong>
        </div>
    </footer>
)}