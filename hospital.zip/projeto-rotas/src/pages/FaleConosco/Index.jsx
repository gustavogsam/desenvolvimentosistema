import './style.css'

export default function FaleConosco(){
    function handleSubmit(event){
        event.preventDefalut()
        alert("Mensagem enviada com sucesso.")
    }

    return(
        <section className='contato'>
            <h1>Fale conosco</h1>
            <p>Faça um consulta e encontre o plano ideal para voce </p>

            <form className='form' onSubmit={handleSubmit}>
                <div>
                    <label className='campo'>
                        <span>Nome</span>
                        <input type="text" required placeholder='Seu nome' />
                    </label>

                     <label className='campo'>
                        <span>E-mail</span>
                        <input type="text" required placeholder='Seu e-mail' />
                    </label>

                     <label className='campo'>
                        <span>Telefone</span>
                        <input type="text" required placeholder='(00) 99999-9999'/>
                    </label>
                </div>

                

                    <button type='submit'>Enviar</button>
            </form>

        </section>
    )

}
