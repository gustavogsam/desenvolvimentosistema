import { Link } from 'react-router-dom'
import logo from '../../assets/logo.png'
import './style.css'


    export default function Home() {
    return (
        <div className="home">
            <section className="logo">
                <div>
                    <h1>Aparelhos mais modernos do mercado</h1>
                    <p>Invista na sua saúde, que ela vale ouro</p>

                    <div>
                        <Link to="/fale-conosco">Fale conosco</Link>
                    </div>
                </div>

           
            </section>

            <section>
                <h2>Por que nos escolher?</h2>

                <div>
                    <div className="card">
                        <h3>Leitos confortáveis</h3>
                        <p>A mais alta qualidade para te acolher nos momentos difíceis.</p>
                    </div>

                    <div className="card">
                        <h3>Emergência 24 horas</h3>
                        <p>Ambulâncias disponíveis e bem equipadas, caso necessário.</p>
                    </div>

                    <div className="card">
                        <h3>UTI</h3>
                        <p>Equipamentos mais modernos do mercado.</p>
                    </div>
                </div>
            </section>
        </div>
    );
}