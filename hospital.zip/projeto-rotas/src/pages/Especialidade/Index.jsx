import './style.css'

export default function Especialidade(){
    return(
        <section>
            <h2>Somos Especialista em cirugia Cardiaca</h2>
            <p>
                Nossos cirugiões tem muita experiencia nessa área
                contamos com a mais qualidade. Com equipamento ligado
                a esses tipo de procedimento.
                
            </p>

            <ul>
                <li>mais de 20 mil cirugias realizadas com sucesso</li>
                
            </ul>
        </section>
    )
}