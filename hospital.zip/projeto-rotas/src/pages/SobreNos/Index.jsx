import './style.css'

export default function SobreNos(){
    return(
        <section>
            <h1>Sobre nós</h1>
            <p>
                Somos um hospital com muito profissionais experiente com varios anos no mercador.
                Contamos com uma estrutura ideal para atender voce e a sua familia para nós voce não
                são apenas cliente mais sim parte da nossa familia.
                
            </p>

            <ul>
                <li>Estamos a 30 anos cuidamos de nosso pacientes</li>
                
            </ul>
        </section>
    )
}